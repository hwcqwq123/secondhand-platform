# AI 客服、用户聊天、内容审核、本地开源模型部署补充说明

## 本次补齐的功能

1. AI 客服入口：`frontend/src/components/AiChatWidget.vue`
   - 右下角悬浮 AI 客服窗口。
   - 用户输入问题后调用后端 `/api/ai/chat`。
   - 返回 AI 回答和推荐商品卡片。

2. AI 客服大模型问答：`backend/src/main/java/com/example/secondhand/ai/`
   - 新增 `AiController.java`、`AiService.java`、`AiChatRequest.java`、`AiChatResponse.java`、`AiMessage.java`。
   - 支持 OpenAI-compatible API。
   - 默认使用本地 Ollama：`http://127.0.0.1:11434/v1`。
   - 默认模型：`qwen3:4b`，也可改成 `deepseek-r1:7b`。
   - 大模型失败时自动降级为本地规则商品推荐回答。

3. AI 商品推荐
   - 保留原有 `/api/recommendations` 行为推荐。
   - AI 客服内部也会根据用户输入从商品库中检索候选商品，并作为回答上下文和商品卡片返回。

4. 用户之间聊天后端
   - 保留并使用 `/api/chats/**`。
   - 支持创建会话、查询会话列表、查询消息、发送消息、标记已读。

5. 用户之间聊天前端
   - 新增 `frontend/src/components/ChatPage.vue`。
   - 修复原来 `App.vue` 中聊天页放在商品详情弹窗内部的问题。
   - 现在 `currentView === 'chats'` 时聊天页作为一级页面展示。
   - 使用 3 秒轮询刷新消息。

6. 聊天消息审核与商品发布审核
   - 聊天消息发送前调用 `ContentAuditService.auditChatMessage()`。
   - 商品发布和编辑前调用 `ContentAuditService.auditItem()`。
   - Spring Boot 后端调用 Python 审核服务：`http://127.0.0.1:8001/audit`。

7. 本地规则审核和本地违禁词库
   - `audit-service/banned_words.txt`：本地违禁词库。
   - `audit-service/main.py`：本地正则规则审核。

8. 国产开源免费模型本地部署
   - 使用 Ollama 在本地运行国产开源模型。
   - 推荐千问：`ollama pull qwen3:4b`。
   - 推荐 DeepSeek：`ollama pull deepseek-r1:7b`。
   - 审核服务和 AI 客服都走 OpenAI-compatible 接口。

## 推荐运行顺序

### 1. 启动本地大模型

```bash
ollama pull qwen3:4b
ollama serve
```

或者：

```bash
ollama pull deepseek-r1:7b
ollama serve
```

### 2. 启动 Python 审核服务

```bash
cd audit-service
pip install -r requirements.txt

# 使用本地千问模型审核
set AUDIT_USE_LLM=true
set AUDIT_LLM_BASE_URL=http://127.0.0.1:11434/v1
set AUDIT_LLM_MODEL=qwen3:4b
python main.py
```

如果是 PowerShell：

```powershell
$env:AUDIT_USE_LLM="true"
$env:AUDIT_LLM_BASE_URL="http://127.0.0.1:11434/v1"
$env:AUDIT_LLM_MODEL="qwen3:4b"
python main.py
```

### 3. 启动 Spring Boot 后端

```bash
cd backend
mvn spring-boot:run
```

### 4. 启动前端

```bash
cd frontend
npm install
npm run dev
```

## 如果要换成在线 DeepSeek API

修改 `backend/src/main/resources/application.yml`：

```yaml
app:
  ai:
    enabled: true
    provider: deepseek
    base-url: https://api.deepseek.com
    api-key: "你的 DeepSeek API Key"
    model: deepseek-chat
```

Python 审核服务环境变量：

```powershell
$env:AUDIT_USE_LLM="true"
$env:AUDIT_LLM_BASE_URL="https://api.deepseek.com"
$env:AUDIT_LLM_API_KEY="你的 DeepSeek API Key"
$env:AUDIT_LLM_MODEL="deepseek-chat"
python main.py
```

## 如果要换成阿里云百炼 / 通义千问 API

修改 `backend/src/main/resources/application.yml`：

```yaml
app:
  ai:
    enabled: true
    provider: qwen-dashscope
    base-url: https://dashscope.aliyuncs.com/compatible-mode/v1
    api-key: "你的 DashScope API Key"
    model: qwen-plus
```

Python 审核服务环境变量：

```powershell
$env:AUDIT_USE_LLM="true"
$env:AUDIT_LLM_BASE_URL="https://dashscope.aliyuncs.com/compatible-mode/v1"
$env:AUDIT_LLM_API_KEY="你的 DashScope API Key"
$env:AUDIT_LLM_MODEL="qwen-plus"
python main.py
```

## 答辩表述

本项目实现了 AI 客服入口、大模型问答、商品推荐、用户之间私信聊天、聊天消息审核、商品发布审核、本地违禁词库审核、本地正则规则审核，并支持国产开源模型本地部署。AI 客服和审核服务均采用 OpenAI-compatible 接口，因此可以接入本地 Ollama 部署的 Qwen3、DeepSeek-R1，也可以切换到 DeepSeek 官方 API 或阿里云百炼 / 通义千问 API。
