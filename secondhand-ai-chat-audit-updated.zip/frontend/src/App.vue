<template>
  <TopBar
      v-model="q"
      :token="token"
      :userInfo="profile"
      @search="handleSearch"
      @openAuth="openAuthDialog('login')"
      @logout="logout"
      @goHome="switchView('home')"
      @goOrders="switchView('orders')"
      @goProfile="switchView('profile')"
      @goPost="handleGoPost"
      @goMyItems="switchView('myItems')"
      @goChats="switchView('chats')"
  />

  <!-- 首页 -->
  <template v-if="currentView === 'home'">
    <div class="container page-section">
      <div class="hero-card">
        <div class="hero-title">校园闲置，轻松流转</div>
        <div class="hero-desc">发布、浏览、下单、聊天、推荐与 AI 客服一体化，让校内二手交易更方便。</div>
      </div>
    </div>

    <div class="container layout">
      <div class="row">
        <div class="left col">
          <BoardNav :boards="boards" :active="activeBoard" @select="selectBoard" />
        </div>

        <div class="main col">
          <ItemList
              :items="items"
              :title="listTitle"
              :total="items.length"
              :error="listError"
              @open="openDetail"
              @buy="doCreateOrder"
          />

          <div class="card section-spacing">
            <div class="list-head">
              <div class="title">为你推荐</div>
              <button class="btn" @click="loadRecs" :disabled="!token">刷新推荐</button>
            </div>

            <div class="mini-grid">
              <div
                  v-for="r in recs"
                  :key="r.id"
                  class="mini-item"
                  @click="openDetail(r.id)"
              >
                <img v-if="r.coverImageUrl" :src="r.coverImageUrl" alt="商品封面" />
                <div v-else class="img-empty">图片</div>
                <div class="mini-title">{{ r.title }}</div>
                <div class="price">¥ {{ r.price }}</div>
              </div>
              <div v-if="recs.length === 0" class="muted">暂无推荐（登录并多浏览几个商品试试）</div>
            </div>
            <div v-if="recErr" class="msg">{{ recErr }}</div>
          </div>
        </div>

        <div class="right col">
          <SideBar @filter="quickFilter" />
          <div class="card section-spacing">
            <div class="sidebar-section">
              <div class="sidebar-title">当前状态</div>
              <div class="kv"><span>登录</span><span>{{ token ? '已登录' : '未登录' }}</span></div>
              <div class="kv"><span>板块</span><span>{{ boardsMap[activeBoard] }}</span></div>
              <div class="kv"><span>关键词</span><span>{{ q || '-' }}</span></div>
              <div class="kv"><span>筛选</span><span>{{ status || '全部' }}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>

  <!-- 发布/编辑商品 -->
  <div v-if="currentView === 'post'" class="container page-section">
    <div class="page-title">{{ isEditMode ? '编辑商品' : '发布商品' }}</div>
    <div class="card narrow">
      <div class="list-head">
        <div class="title">填写商品信息</div>
        <button class="btn" @click="switchView('home')">返回首页</button>
      </div>

      <div class="form">
        <div class="grid">
          <input v-model="form.title" placeholder="标题（如：二手耳机）" />
          <input v-model="form.price" placeholder="价格（如：99.00）" />
          <select v-model="form.board">
            <option value="digital">数码</option>
            <option value="books">书籍</option>
            <option value="daily">日用</option>
            <option value="sports">运动</option>
          </select>
          <input class="full" v-model="form.description" placeholder="描述（成色/配件/交易方式）" />
        </div>

        <div class="section-spacing">
          <div class="title small">上传图片</div>
          <div class="upload-grid">
            <label v-if="postImages.length < 3" class="upload-box">
              <input type="file" accept="image/*" multiple hidden @change="handleSelectImages" />
              <div class="upload-plus">+</div>
              <div>{{ uploading ? '上传中...' : '上传图片' }}</div>
              <small>最多 3 张</small>
            </label>

            <div v-for="(img, index) in postImages" :key="img.url" class="upload-preview" :class="{ active: coverIndex === index }">
              <img :src="img.url" alt="商品图片" />
              <div class="panel-actions compact">
                <button class="btn" :class="{ primary: coverIndex === index }" @click="setCover(index)">
                  {{ coverIndex === index ? '当前封面' : '设为封面' }}
                </button>
                <button class="btn" @click="removeImage(index)">删除</button>
              </div>
            </div>
          </div>
        </div>

        <div class="panel-actions">
          <button class="btn primary" @click="isEditMode ? updatePost() : createPost()" :disabled="uploading">
            {{ isEditMode ? '保存修改' : '立即发布' }}
          </button>
          <button v-if="isEditMode" class="btn" @click="cancelEdit">取消编辑</button>
          <button class="btn" @click="resetPostForm">清空内容</button>
        </div>
        <div v-if="postError" class="msg">{{ postError }}</div>
      </div>
    </div>
  </div>

  <!-- 我的订单 -->
  <div v-if="currentView === 'orders'" class="container page-section">
    <div class="page-title">我的订单</div>
    <div class="card">
      <div class="list-head">
        <div class="title">订单列表</div>
        <button class="btn" @click="loadOrders(); loadSalesOrders()">刷新</button>
      </div>
      <div class="panel-actions">
        <button class="btn" :class="{ primary: orderTab === 'buy' }" @click="orderTab = 'buy'">我购买的</button>
        <button class="btn" :class="{ primary: orderTab === 'sell' }" @click="orderTab = 'sell'">我发布的</button>
      </div>

      <div v-if="orderTab === 'buy'">
        <div v-if="orderError" class="msg">{{ orderError }}</div>
        <div v-if="orders.length === 0" class="muted">暂无购买订单</div>
        <div v-for="order in orders" :key="order.id" class="order-card">
          <div>
            <b>{{ order.item?.title || '未命名商品' }}</b>
            <div class="price">¥ {{ order.item?.price ?? '-' }}</div>
            <div class="muted">卖家：{{ order.item?.seller?.nickname || order.item?.seller?.username || '-' }}</div>
            <div class="muted">订单状态：{{ order.status }} ｜ 商品状态：{{ order.item?.status || '-' }}</div>
          </div>
          <div class="panel-actions compact">
            <button v-if="order.status === 'CREATED'" class="btn primary" @click="openPayDialog(order)">去支付</button>
            <button v-if="order.status === 'CREATED'" class="btn" @click="doCancelOrder(order.id)">取消订单</button>
            <button v-if="order.item?.id" class="btn" @click="openDetail(order.item.id)">查看商品</button>
          </div>
        </div>
      </div>

      <div v-else>
        <div v-if="salesOrderError" class="msg">{{ salesOrderError }}</div>
        <div v-if="salesOrders.length === 0" class="muted">暂无卖出订单</div>
        <div v-for="order in salesOrders" :key="order.id" class="order-card">
          <div>
            <b>{{ order.item?.title || '未命名商品' }}</b>
            <div class="price">¥ {{ order.item?.price ?? '-' }}</div>
            <div class="muted">买家：{{ order.buyer?.nickname || order.buyer?.username || '-' }}</div>
            <div class="muted">订单状态：{{ order.status }} ｜ 商品状态：{{ order.item?.status || '-' }}</div>
          </div>
          <button v-if="order.item?.id" class="btn" @click="openDetail(order.item.id)">查看商品</button>
        </div>
      </div>
    </div>
  </div>

  <!-- 个人中心 -->
  <div v-if="currentView === 'profile'" class="container page-section">
    <div class="page-title">个人中心</div>
    <div class="card narrow">
      <div class="list-head">
        <div class="title">个人资料</div>
        <button class="btn primary" @click="saveProfile">保存资料</button>
      </div>
      <div class="form">
        <div class="grid">
          <input v-model="profile.nickname" placeholder="昵称" />
          <input v-model="profile.avatarUrl" placeholder="头像图片地址（URL）" />
          <input class="full" v-model="profile.bio" placeholder="个人简介" />
        </div>
        <div v-if="profileMsg" class="msg">{{ profileMsg }}</div>
      </div>
    </div>

    <div class="card narrow section-spacing">
      <div class="list-head">
        <div class="title">支付设置</div>
        <button class="btn primary" @click="savePayment">保存收款码</button>
      </div>
      <div class="form">
        <input v-model="profile.wechatQrUrl" placeholder="微信收款码图片地址（URL）" />
        <div v-if="profile.wechatQrUrl" class="qr-box"><img :src="profile.wechatQrUrl" alt="收款码" /></div>
        <div v-if="paymentMsg" class="msg">{{ paymentMsg }}</div>
      </div>
    </div>
  </div>

  <!-- 我的发布 -->
  <div v-if="currentView === 'myItems'" class="container page-section">
    <div class="page-title">我的发布</div>
    <div class="card">
      <div class="list-head">
        <div class="title">我发布的商品</div>
        <button class="btn" @click="loadMyItems">刷新</button>
      </div>
      <div v-if="myItemsError" class="msg">{{ myItemsError }}</div>
      <div v-if="myItems.length === 0" class="muted">暂无已发布商品</div>
      <div v-for="item in myItems" :key="item.id" class="order-card">
        <div>
          <b>{{ item.title }}</b>
          <div class="price">¥ {{ item.price }}</div>
          <div class="muted">商品状态：{{ item.status }}</div>
        </div>
        <div class="panel-actions compact">
          <button class="btn" @click="openEditItem(item)">编辑</button>
          <button v-if="item.status !== 'OFF_SHELF'" class="btn" @click="doOffShelf(item.id)">下架</button>
          <button v-else class="btn primary" @click="doPutOnShelf(item.id)">重新上架</button>
          <button v-if="item.status === 'OFF_SHELF'" class="btn" @click="doDeleteItem(item.id)">删除</button>
          <button class="btn" @click="openDetail(item.id)">查看详情</button>
        </div>
      </div>
    </div>
  </div>

  <!-- 修改：聊天页放在页面一级，不再嵌套在商品详情弹窗里 -->
  <div v-if="currentView === 'chats'" class="container page-section">
    <ChatPage :initialConversationId="chatInitialConversationId" @openDetail="openDetail" />
  </div>

  <!-- 商品详情弹窗 -->
  <div v-if="showDetail" class="modal-mask">
    <div class="card modal-card">
      <div class="list-head">
        <div class="title">商品详情</div>
        <button class="btn" @click="showDetail = false">关闭</button>
      </div>
      <div class="detail-body">
        <div class="detail-cover">
          <img v-if="detail?.imageUrls?.length" :src="detail.imageUrls[0]" alt="商品图片" />
          <img v-else-if="detail?.coverImageUrl" :src="detail.coverImageUrl" alt="商品封面" />
          <span v-else>图片</span>
        </div>
        <div class="detail-info">
          <h2>{{ detail?.title }}</h2>
          <div class="price big">¥ {{ detail?.price }}</div>
          <p>{{ detail?.description || '（无描述）' }}</p>
          <div class="muted">卖家：{{ detail?.seller?.nickname || detail?.seller?.username || '-' }} ｜ 状态：{{ detail?.status }}</div>
          <div class="panel-actions">
            <button class="btn primary" @click="doCreateOrder(detail?.id)" :disabled="!detail || detail.status !== 'AVAILABLE'">
              {{ token ? '下单' : '登录后下单' }}
            </button>
            <button class="btn" @click="openChatByItem(detail)" :disabled="!detail || detail.status === 'OFF_SHELF'">
              联系卖家
            </button>
          </div>
          <div v-if="detailErr" class="msg">{{ detailErr }}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- 支付弹窗 -->
  <div v-if="showPayDialog" class="modal-mask">
    <div class="card pay-card">
      <div class="list-head">
        <div class="title">订单支付</div>
        <button class="btn" @click="showPayDialog = false">关闭</button>
      </div>
      <p>请扫码向卖家支付，完成后点击“我已完成支付”。</p>
      <div class="qr-box large">
        <img v-if="payOrderInfo?.item?.seller?.wechatQrUrl" :src="payOrderInfo.item.seller.wechatQrUrl" alt="卖家收款码" />
        <span v-else>卖家暂未上传收款码</span>
      </div>
      <div class="panel-actions">
        <button class="btn primary" @click="doPayOrder(payOrderInfo.id)" :disabled="!payOrderInfo">我已完成支付</button>
        <button class="btn" @click="doCancelOrder(payOrderInfo.id)" :disabled="!payOrderInfo">取消订单</button>
      </div>
      <div v-if="payMsg" class="msg">{{ payMsg }}</div>
    </div>
  </div>

  <AiChatWidget v-if="token" @openDetail="openDetail" />

  <!-- 登录弹窗 -->
  <div v-if="showAuthDialog" class="modal-mask top">
    <div class="card auth-card">
      <div class="list-head">
        <div class="title">{{ authMode === 'login' ? '用户登录' : '用户注册' }}</div>
        <button class="btn" @click="closeAuthDialog">关闭</button>
      </div>
      <div class="form">
        <div class="panel-actions">
          <button class="btn" :class="{ primary: authMode === 'login' }" @click="authMode = 'login'; authError = ''">登录</button>
          <button class="btn" :class="{ primary: authMode === 'register' }" @click="authMode = 'register'; authError = ''">注册</button>
        </div>
        <input v-model="auth.username" placeholder="请输入用户名" />
        <input v-model="auth.password" type="password" placeholder="请输入密码" />
        <button v-if="authMode === 'login'" class="btn primary" @click="doLogin">立即登录</button>
        <button v-else class="btn primary" @click="doRegister">立即注册</button>
        <div v-if="authError" class="msg">{{ authError }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import './styles/app.css'
import { reactive, ref, computed, onMounted } from 'vue'

import TopBar from './components/TopBar.vue'
import BoardNav from './components/BoardNav.vue'
import ItemList from './components/ItemList.vue'
import SideBar from './components/SideBar.vue'
import AiChatWidget from './components/AiChatWidget.vue'
import ChatPage from './components/ChatPage.vue'

import {
  register,
  login,
  listItems,
  createItem,
  createOrder,
  getItemDetail,
  getRecommendations,
  getMyProfile,
  updateMyProfile,
  updateMyPayment,
  updateItem,
  deleteItem,
  listMyOrders,
  listMySalesOrders,
  listMyItems,
  offShelfItem,
  putOnShelfItem,
  payOrder,
  cancelOrder,
  uploadImage,
  openChatForItem
} from './api'

const token = ref(localStorage.getItem('token') || '')
const q = ref('')
const status = ref('')
const currentView = ref('home')
const chatInitialConversationId = ref(null)

const showAuthDialog = ref(false)
const authMode = ref('login')
const auth = reactive({ username: '', password: '' })
const authError = ref('')

const form = reactive({ title: '', price: '', description: '', board: 'digital' })
const isEditMode = ref(false)
const editingItemId = ref(null)
const postImages = ref([])
const coverIndex = ref(0)
const uploading = ref(false)
const postError = ref('')

const items = ref([])
const listError = ref('')
const recs = ref([])
const recErr = ref('')

const showDetail = ref(false)
const detail = ref(null)
const detailErr = ref('')

const orders = ref([])
const salesOrders = ref([])
const orderError = ref('')
const salesOrderError = ref('')
const orderTab = ref('buy')

const myItems = ref([])
const myItemsError = ref('')

const showPayDialog = ref(false)
const payOrderInfo = ref(null)
const payMsg = ref('')

const profile = reactive({
  id: null,
  username: '',
  role: '',
  nickname: '',
  avatarUrl: '',
  bio: '',
  wechatQrUrl: ''
})
const profileMsg = ref('')
const paymentMsg = ref('')

const boards = [
  { key: 'all', name: '全部' },
  { key: 'digital', name: '数码' },
  { key: 'books', name: '书籍' },
  { key: 'daily', name: '日用' },
  { key: 'sports', name: '运动' }
]
const boardsMap = boards.reduce((m, x) => ({ ...m, [x.key]: x.name }), {})
const activeBoard = ref('all')

const listTitle = computed(() => `帖子列表 - ${boardsMap[activeBoard.value] || '全部'}（${status.value || '全部'}）`)

function setToken(res) {
  if (!res.success) throw new Error(res.message || '认证失败')
  localStorage.setItem('token', res.data.token)
  token.value = res.data.token
}

function fillProfile(data) {
  profile.id = data?.id ?? null
  profile.username = data?.username ?? ''
  profile.role = data?.role ?? ''
  profile.nickname = data?.nickname ?? ''
  profile.avatarUrl = data?.avatarUrl ?? ''
  profile.bio = data?.bio ?? ''
  profile.wechatQrUrl = data?.wechatQrUrl ?? ''
}

function openAuthDialog(mode = 'login', message = '') {
  authMode.value = mode
  authError.value = message
  showAuthDialog.value = true
}
function closeAuthDialog() { showAuthDialog.value = false; authError.value = '' }
function requireLogin(message = '请先登录后再继续操作') {
  if (token.value) return true
  openAuthDialog('login', message)
  return false
}

async function doRegister() {
  authError.value = ''
  try {
    setToken(await register(auth.username, auth.password))
    closeAuthDialog()
    await loadInitialData()
  } catch (e) { authError.value = e.message }
}
async function doLogin() {
  authError.value = ''
  try {
    setToken(await login(auth.username, auth.password))
    closeAuthDialog()
    await loadInitialData()
  } catch (e) { authError.value = e.message }
}
function logout() {
  localStorage.removeItem('token')
  token.value = ''
  recs.value = []
  orders.value = []
  salesOrders.value = []
  myItems.value = []
  fillProfile(null)
  currentView.value = 'home'
  loadItems()
}

function selectBoard(key) { activeBoard.value = key; loadItems() }
function quickFilter(s) { status.value = s; loadItems() }
function handleSearch() { currentView.value = 'home'; loadItems() }
function handleGoPost() { if (requireLogin('请先登录后再发布商品')) currentView.value = 'post' }

async function loadItems() {
  listError.value = ''
  try {
    const res = await listItems({ q: q.value || undefined, status: status.value || undefined, board: activeBoard.value })
    if (!res.success) throw new Error(res.message || '加载商品失败')
    items.value = res.data || []
  } catch (e) { listError.value = e.message }
}

function resetPostForm() {
  form.title = ''; form.price = ''; form.description = ''; form.board = 'digital'
  postImages.value = []; coverIndex.value = 0; postError.value = ''
  isEditMode.value = false; editingItemId.value = null
}
function cancelEdit() { resetPostForm(); currentView.value = 'myItems' }

async function createPost() {
  postError.value = ''
  if (!requireLogin('请先登录后再发布商品')) return
  try {
    const res = await createItem({
      title: form.title,
      description: form.description,
      price: form.price,
      board: form.board,
      imageUrls: postImages.value.map(img => img.url),
      coverIndex: postImages.value.length ? coverIndex.value : 0
    })
    if (!res.success) throw new Error(res.message || '发布失败')
    resetPostForm(); await loadItems(); currentView.value = 'home'
  } catch (e) { postError.value = e.message }
}

async function updatePost() {
  postError.value = ''
  if (!requireLogin('请先登录后再编辑商品')) return
  try {
    const res = await updateItem(editingItemId.value, {
      title: form.title,
      description: form.description,
      price: form.price,
      board: form.board,
      imageUrls: postImages.value.map(img => img.url),
      coverIndex: postImages.value.length ? coverIndex.value : 0
    })
    if (!res.success) throw new Error(res.message || '更新失败')
    resetPostForm(); await loadMyItems(); await loadItems(); currentView.value = 'myItems'
  } catch (e) { postError.value = e.message }
}

async function handleSelectImages(event) {
  const files = Array.from(event.target.files || [])
  if (!files.length) return
  const selected = files.slice(0, 3 - postImages.value.length)
  uploading.value = true; postError.value = ''
  try {
    for (const file of selected) {
      const res = await uploadImage(file)
      if (!res.success) throw new Error(res.message || '图片上传失败')
      postImages.value.push({ url: res.data.url })
    }
  } catch (e) { postError.value = e.message || '图片上传失败' }
  finally { uploading.value = false; event.target.value = '' }
}
function setCover(index) { coverIndex.value = index }
function removeImage(index) { postImages.value.splice(index, 1); if (coverIndex.value >= postImages.value.length) coverIndex.value = 0 }

async function openDetail(id) {
  detailErr.value = ''
  try {
    const res = await getItemDetail(id)
    if (!res.success) throw new Error(res.message || '加载详情失败')
    detail.value = res.data
    showDetail.value = true
  } catch (e) { detailErr.value = e.message }
}

async function openChatByItem(item) {
  detailErr.value = ''
  if (!item?.id) return
  if (!requireLogin('请先登录后再联系卖家')) return
  if (item?.seller?.id === profile.id) { detailErr.value = '不能和自己聊天'; return }
  try {
    const res = await openChatForItem(item.id)
    if (!res.success) throw new Error(res.message || '打开聊天失败')
    chatInitialConversationId.value = res.data.id
    showDetail.value = false
    currentView.value = 'chats'
  } catch (e) { detailErr.value = e.message || '打开聊天失败' }
}

async function doCreateOrder(itemId) {
  if (!itemId) return
  if (!requireLogin('请先登录后再下单')) return
  detailErr.value = ''
  try {
    const res = await createOrder(itemId)
    if (!res.success) throw new Error(res.message || '下单失败')
    showDetail.value = false
    currentView.value = 'orders'
    await Promise.allSettled([loadOrders(), loadSalesOrders(), loadItems(), loadRecs()])
  } catch (e) {
    detailErr.value = e.message || '下单失败'
    await loadItems()
  }
}

async function loadRecs() {
  recErr.value = ''
  if (!token.value) { recs.value = []; recErr.value = '登录后可查看个性化推荐'; return }
  try {
    const res = await getRecommendations(8)
    if (!res.success) throw new Error(res.message || '推荐加载失败')
    recs.value = (res.data || []).filter(item => item.status !== 'OFF_SHELF')
  } catch (e) { recErr.value = e.message || '推荐加载失败' }
}
async function loadOrders() {
  orderError.value = ''
  if (!requireLogin('请先登录后再查看订单')) return
  try { const res = await listMyOrders(); if (!res.success) throw new Error(res.message || '订单加载失败'); orders.value = res.data || [] }
  catch (e) { orderError.value = e.message }
}
async function loadSalesOrders() {
  salesOrderError.value = ''
  if (!requireLogin('请先登录后再查看卖出订单')) return
  try { const res = await listMySalesOrders(); if (!res.success) throw new Error(res.message || '卖出订单加载失败'); salesOrders.value = res.data || [] }
  catch (e) { salesOrderError.value = e.message }
}
function openPayDialog(order) { payMsg.value = ''; payOrderInfo.value = order; showPayDialog.value = true }
async function doPayOrder(orderId) {
  payMsg.value = ''
  if (!requireLogin('请先登录后再支付订单')) return
  try { const res = await payOrder(orderId); if (!res.success) throw new Error(res.message || '支付失败'); payMsg.value = '支付成功'; await loadOrders(); await loadItems() }
  catch (e) { payMsg.value = e.message }
}
async function doCancelOrder(orderId) {
  if (!requireLogin('请先登录后再取消订单')) return
  try { const res = await cancelOrder(orderId); if (!res.success) throw new Error(res.message || '取消失败'); showPayDialog.value = false; await loadOrders(); await loadItems() }
  catch (e) { payMsg.value = e.message; orderError.value = e.message }
}

async function loadProfile() {
  profileMsg.value = ''; paymentMsg.value = ''
  if (!requireLogin('请先登录后再查看个人中心')) return
  try { const res = await getMyProfile(); if (!res.success) throw new Error(res.message || '个人信息加载失败'); fillProfile(res.data) }
  catch (e) { profileMsg.value = e.message }
}
async function saveProfile() {
  profileMsg.value = ''
  if (!requireLogin('请先登录后再保存资料')) return
  try { const res = await updateMyProfile({ nickname: profile.nickname, avatarUrl: profile.avatarUrl, bio: profile.bio }); if (!res.success) throw new Error(res.message || '保存失败'); fillProfile(res.data); profileMsg.value = '个人资料已保存' }
  catch (e) { profileMsg.value = e.message }
}
async function savePayment() {
  paymentMsg.value = ''
  if (!requireLogin('请先登录后再保存收款码')) return
  try { const res = await updateMyPayment({ wechatQrUrl: profile.wechatQrUrl }); if (!res.success) throw new Error(res.message || '保存失败'); fillProfile(res.data); paymentMsg.value = '收款码已保存' }
  catch (e) { paymentMsg.value = e.message }
}

async function loadMyItems() {
  myItemsError.value = ''
  if (!requireLogin('请先登录后再查看我的发布')) return
  try { const res = await listMyItems(); if (!res.success) throw new Error(res.message || '加载失败'); myItems.value = res.data || [] }
  catch (e) { myItemsError.value = e.message }
}
async function openEditItem(item) {
  if (!requireLogin('请先登录后再编辑商品')) return
  try {
    const res = await getItemDetail(item.id)
    if (!res.success) throw new Error(res.message || '加载商品详情失败')
    const full = res.data
    isEditMode.value = true; editingItemId.value = full.id
    form.title = full.title || ''; form.price = full.price ?? ''; form.description = full.description || ''; form.board = full.board || 'digital'
    postImages.value = (full.imageUrls || []).map(url => ({ url }))
    coverIndex.value = 0
    currentView.value = 'post'
  } catch (e) { myItemsError.value = e.message }
}
async function doOffShelf(id) { try { const res = await offShelfItem(id); if (!res.success) throw new Error(res.message || '下架失败'); await loadMyItems(); await loadItems() } catch (e) { myItemsError.value = e.message } }
async function doPutOnShelf(id) { try { const res = await putOnShelfItem(id); if (!res.success) throw new Error(res.message || '上架失败'); await loadMyItems(); await loadItems() } catch (e) { myItemsError.value = e.message } }
async function doDeleteItem(id) { try { const res = await deleteItem(id); if (!res.success) throw new Error(res.message || '删除失败'); await loadMyItems(); await loadItems() } catch (e) { myItemsError.value = e.message } }

function switchView(view) {
  const protectedViews = ['orders', 'profile', 'myItems', 'post', 'chats']
  if (protectedViews.includes(view) && !requireLogin('请先登录后再使用该功能')) return
  currentView.value = view
  if (view === 'orders') { loadOrders(); loadSalesOrders() }
  if (view === 'profile') loadProfile()
  if (view === 'myItems') loadMyItems()
}
async function loadInitialData() {
  await loadItems()
  if (token.value) await Promise.allSettled([loadRecs(), loadProfile()])
}

onMounted(loadInitialData)
</script>
